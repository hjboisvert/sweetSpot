﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JClicked : MonoBehaviour {

	public ButtonType buttonType;

	[SerializeField]
	bool Clicked = false;

	public bool CL{
		get{
			return Clicked;
		}
		set{
			Clicked = value;
		}
	}

	public string SceneName;
	public string MenuName;

	public enum ButtonType
	{
		NONE,
		MENU_OPTION,
		GAME_SCENE,
	}

	public Transform ReturnTransform()
	{
		return gameObject.transform;
	}

	void OnMouseDown()
	{
		Debug.Log ("Clicked!");
		Clicked = true;
		ReturnTransform ();
	}
}

	/*void OnMouseOver()
	{
		Debug.Log ("MouseOver: " + " " + gameObject.name + " Button");
	}*/