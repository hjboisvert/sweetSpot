﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(JClicked), true)]
[CanEditMultipleObjects]
public class JClickedEditor : Editor {

	JClicked _evCtrl = null;

	void OnEnable()
	{
		_evCtrl = (JClicked)target;
	}
		
	public override void OnInspectorGUI() {
		
		GUILayout.BeginHorizontal ();
		GUILayout.Label ("Button Type", GUILayout.Width (70));
		_evCtrl.buttonType = (JClicked.ButtonType)EditorGUILayout.EnumPopup (_evCtrl.buttonType);
		GUILayout.EndHorizontal ();

		if (_evCtrl.buttonType == JClicked.ButtonType.MENU_OPTION) {
			GUILayout.Space (5);
			GUILayout.BeginHorizontal ();
			GUILayout.Label ("Clicked Status", GUILayout.Width (80));
			_evCtrl.CL = EditorGUILayout.Toggle (_evCtrl.CL);
			GUILayout.EndHorizontal ();

			GUILayout.BeginHorizontal ();
			GUILayout.Label ("Menu Name", GUILayout.Width (70));
			_evCtrl.MenuName = EditorGUILayout.TextField (_evCtrl.MenuName);
			GUILayout.EndHorizontal ();
		}
			
		if (_evCtrl.buttonType == JClicked.ButtonType.GAME_SCENE) {
			GUILayout.Space (5);
			GUILayout.BeginHorizontal ();
			GUILayout.Label ("Clicked Status", GUILayout.Width (80));
			_evCtrl.CL = EditorGUILayout.Toggle (_evCtrl.CL);
			GUILayout.EndHorizontal ();

			GUILayout.BeginHorizontal ();
			GUILayout.Label ("Scene Name", GUILayout.Width (70));
			_evCtrl.SceneName = EditorGUILayout.TextField (_evCtrl.SceneName);
			GUILayout.EndHorizontal ();
		}
	}
}
